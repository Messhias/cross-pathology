Used template:

https://github.com/puikinsh/gentelella
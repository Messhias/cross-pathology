
var url_development = 'http://localhost/cross-pathology/';
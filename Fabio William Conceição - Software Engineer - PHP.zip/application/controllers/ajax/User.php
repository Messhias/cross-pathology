<?php


/**
 * @package	CONTROLLER
 * @author 	FABIO WILLIAM CONCEIÇÃO
 * @since 	VERSION 1.0.0
 * @filesource
*/



defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {




	/**
	 * @access	public
	 * @method 	post
	 * @since 	VERSION 1.0.0
	 * @filesource
	*/
	public function newUser()
	{
	}

}

/* End of file User.php */
/* Location: ./application/controllers/ajax/User.php */
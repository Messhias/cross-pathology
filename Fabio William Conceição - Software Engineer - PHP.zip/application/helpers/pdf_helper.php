<?php 

	/*
	*
	* HELPER TO USE TO CREATE PDF
	*
	*	@access 		public
	*	@version 		1.0
	*	@filersouce
	*/


	
	/*
	*
	* custom constructor
	*
	*	@access 		public
	*	
	*	@return 		void
	*/	
	function tcpdf()
	{
	    // require_once(BASEPATH.'tcpdf/config/lang/eng.php');
	    require_once('tcpdf/tcpdf.php');
	}

 ?>
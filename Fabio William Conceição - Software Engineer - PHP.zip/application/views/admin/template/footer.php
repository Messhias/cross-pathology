	
	<!-- /main container -->
	</div>
	<!-- /container -->
</div>

    <!-- Custom Theme Scripts -->
    <script src="<?=site_url('assets/build/js/custom.min.js') ?>"></script>
    <script src="<?=site_url('assets/js/functions.js') ?>"></script>
    <script type="text/javascript" src="<?=site_url('assets/js/jquery.form.min.js') ?>"></script>
    <?php if ($js == 'doctor'): ?>
    	<script src="<?=site_url('assets/js/doctor.js') ?>"></script>
    <?php endif ?>

    <div class='loadingMask'>
      <div class="spinner">
        <div class="bounce1"></div>
        <div class="bounce2"></div>
        <div class="bounce3"></div>
      </div>
    </div>

</body>
</html>